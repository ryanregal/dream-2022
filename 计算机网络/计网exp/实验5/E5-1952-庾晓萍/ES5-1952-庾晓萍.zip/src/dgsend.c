#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#include "dgram.h"
//发送数据报，创建一个socket并且用它发送消息到以命令行参数传入的特定的主机和端口号

int main(int argc, char *argv[]) {
  if (argc != 4) {
    fprintf(stderr, "usage: dgsend host port 'message'\n");
    exit(EXIT_FAILURE);
  }
  int sock_id = make_dgram_client_socket();

  struct sockaddr_in saddr;
  make_internet_address(argv[1], atoi(argv[2]), &saddr);
  // 事实上若没有显式 bind, 则调用 sendto/write 就会随机分配端口
  //sendto函数将缓存中的内容发送到特定地址的socket
  //参数：要发送的socket，保存要发送字符串的数组,发送的字符数，flag，发送目的地的socket地址
  sendto(sock_id, argv[3], sizeof(argv[3]), 0, (const struct sockaddr *)&saddr, sizeof(saddr));
  return EXIT_SUCCESS;
}
