extern void setup(void);
extern int get_ticket(void);
extern int release_ticket(void);
extern void shut_down(void);
