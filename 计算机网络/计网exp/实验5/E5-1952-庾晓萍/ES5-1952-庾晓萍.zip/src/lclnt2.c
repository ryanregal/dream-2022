#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int get_ticket();
int release_ticket();
char* do_transcation(char*);
void shut_down();
void set_up();
int validate();
char * license="1234567890";
//客户可以根据系统的需要以一定的时间间隔定期验证票据，可以设置一个计时器来定期验证

void do_regular_work(){
    printf("SuperSleep version 1.0 Running-Licensed Software\n");
    //调试方便，休息20
    sleep(20);
}

int main(int ac,char *av[]){
    if(ac!=2||strncmp(av[1], license, (long unsigned int)10) != 0){
	printf("\nwrong: please input correct license\n");
    	exit(EXIT_FAILURE);  
    }
    else{printf("Verification Succeeded!\n");};
    set_up();
    if(get_ticket()!=0){
        exit(0);
    }
    do_regular_work();
    validate();
    do_regular_work();
    release_ticket();
    shut_down();
}
