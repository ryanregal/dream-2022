#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#include "dgram.h"

//一个简单的基于数据报的服务器。使用命令行传来的端口号建立socket，然后进入循环
//接收和打印从客户端发来的数据报

extern void say_who_called(struct sockaddr_in saddr);

int main(int argc, char *argv[]) {
  int portnum = atoi(argv[1]);
  if (argc != 2 || portnum <= 0) {
    fprintf(stderr, "usage: dgrevc port\n");
    exit(EXIT_FAILURE);
  }

  //辅助函数，在dgram.c定义
  int sock_id = make_dgram_server_socket(portnum);

  char buf[BUFSIZ];
  struct sockaddr_in saddr;
  socklen_t saddrlen = sizeof(saddr);
  int msglen = 0; 
  //在数据报socket中接收消息比从流socket接收简单
  //recvfrom函数阻塞直到数据报到达
  //参数：所要读取的socket，存放字符的数组，要读取的字符数，flag，发送者地址，地址长度
  //返回实际接收的字符数
  while ((msglen = recvfrom(sock_id, buf, BUFSIZ, 0, (struct sockaddr *)&saddr, &saddrlen)) > 0) {
    //当数据报到达时，消息内容，返回地址和其长度将被复制到缓存中。
    buf[msglen] = '\0';
    printf("dgrecv: got a message: %s\n", buf);
    say_who_called(saddr);
  }
  return EXIT_SUCCESS;
}

extern void say_who_called(struct sockaddr_in saddr) {
  char host[BUFSIZ];
  int port;
  //辅助函数，在dgram.c定义
  get_internet_address(host, BUFSIZ, &port, &saddr);
  printf("from: %s:%d\n", host, port);
}
