#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>
#include <stdbool.h>

#include "dgram.h"
#include "lserv_funcs2.h"

#define MSGLEN 128
#define RECLAIM_INTERVAL 5//调试方便，每5秒尝试回收票据
//处理异常崩溃：客户端崩溃，服务器崩溃

/*客户端崩溃：思路：定期检查票据数组，确认其中的每个进程是否还活着
如果否则将进程从数组中去除，释放其占用的票据。
服务器两个操作：（1）等待客户请求（2）周期性回收数据
在处理请求时要关闭alarm（周期性回收，避免冲突）*/

/*服务端崩溃：思路：票据验证
每个客户周期性向服务器发送票据的副本（含有数组编号和PID）。
服务器检查迁出列表，如果为空，则会把该票据加到列表中，逐步地，签出列表被重新填入
问题：如果服务器已经把这个票据分发给了请求的新客户
那么这个旧客户持旧票据进行验证时服务器会拒绝
CLIENT：VALD tickid
SERBER：GOOD or FAIL invalid ticket*/

int main(int argc,char*argv[]) {
  struct sockaddr_in clnt_addr;
  socklen_t addrlen = sizeof(clnt_addr);
  int ret;
  char buf[MSGLEN];
  unsigned int time_left;
  extern int MAXUSERS;//最大使用用户
  char * User="User";
  char * Password="Pass";
  char * license="1234567890";

  if(argc!=4){
    fprintf(stderr, "wrong: please input username and password\n");
    exit(EXIT_FAILURE);
  }
  
  //用户名和密码验证，发放帐号为User，密码为Pass,许可证类型为10或50（人）
  if (strncmp(argv[1], User, (long unsigned int)4) == 0&&
	strncmp(argv[2], Password, (long unsigned int)8) == 0){
	  printf("\nVerify Success!Your license is %s\n", license);
    if(atoi(argv[3])==10){
      MAXUSERS=10;
      printf("You applied for a 10 person license!\n");
    }
    else if(atoi(argv[3])==50){
      MAXUSERS=50;
      printf("You applied for a 50 person license!\n");
    }
    else{    
      fprintf(stderr, "License Type Wrong!\n");
      exit(EXIT_FAILURE);
    }
  }
  else{
    fprintf(stderr, "Username or Password Wrong!\n");
    exit(EXIT_FAILURE);
  }
    

  int sock_fd = setup();
  //增加调度回收票据的函数
  signal(SIGALRM, ticket_reclaim);
  alarm(RECLAIM_INTERVAL);
  while (true) {
    ret = recvfrom(sock_fd, buf, MSGLEN, 0, (struct sockaddr *)&clnt_addr, &addrlen);
    if (ret != -1) {
      buf[ret] = '\0';
      narrate("GOT:", buf, &clnt_addr);
      time_left = alarm(0);//在正常操作中关闭alarm
      handle_request(buf, &clnt_addr, addrlen);
      alarm(time_left);
    }
    else {
      if (errno != EINTR)
        perror("recvfrom");
    }
  }

  return EXIT_SUCCESS;
}
