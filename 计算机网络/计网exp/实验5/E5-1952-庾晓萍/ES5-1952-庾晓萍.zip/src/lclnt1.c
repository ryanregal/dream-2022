#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "lclnt_funcs1.h"



extern void do_regular_work(void);

int main(void) {
  setup();
  //客户端得到票据，进行处理
  if (get_ticket() != 0)
    exit(EXIT_FAILURE);
  do_regular_work();
  //释放票据
  release_ticket();
  shut_down();//退出
  return EXIT_SUCCESS;
}

extern void do_regular_work(void) {
  printf("SuperSleep version 1.0 Running - Licensed Software\n");
  sleep(20);//调试方便，设置为20
  //需要运行许可证服务器，否则sleep函数将拒绝运行
}
