#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>
#include <stdbool.h>

#include "dgram.h"
#include "lserv_funcs1.h"

#define MSGLEN 128

//服务端版本1

int main(void) {
  struct sockaddr_in clnt_addr;
  socklen_t addrlen = sizeof(clnt_addr);
  int ret;
  char buf[MSGLEN];

  int sock_fd = setup();
  //许可证服务器的主函数：循环
  while (true) {
    //接收客户请求
    ret = recvfrom(sock_fd, buf, MSGLEN, 0, (struct sockaddr *)&clnt_addr, &addrlen);
    //处理请求，发送应答
    if (ret != -1) {
      buf[ret] = '\0';
      narrate("GOT:", buf, &clnt_addr);
      //处理请求的代码在lserv_funcs1.c中
      handle_request(buf, &clnt_addr, addrlen);
    }
    else {
      if (errno != EINTR)
        perror("recvfrom");
    }
  }

  return EXIT_SUCCESS;
}
