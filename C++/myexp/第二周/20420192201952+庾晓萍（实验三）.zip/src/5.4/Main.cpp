#include <iostream>
using namespace std;
#define Max(a,b) ((a)>(b)? (a):(b))
#define ABS(a) ((a)>= 0)? (a):(0-(a))
#define Swap(t,x,y) t=x;x=y;y=t;

int main() {
	int a = 1, b = 0,t=0;
	cout << "Max=" << Max(a, b) << endl;
	cout << "ABS=" << ABS(a);
	Swap(t,a,b)
	cout <<endl<< "a=" << a << endl<<"b=" << b;
	/*
	Swap(t,a,b)
	cout<<"max=" << Max(a++, b)<<"  a="<<a << endl;
	//a����ֵ����
	cout<< "max=" << Max(a++, b + 10)<< "  a=" << a <<endl;
	//a����ֵһ��
	*/
}