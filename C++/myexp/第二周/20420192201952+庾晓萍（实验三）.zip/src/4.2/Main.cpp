#include <iostream>
using namespace std;
inline int cube(int);
int main() {
	for (int i=1;i<=10;i++)
	{
		int p = cube(i);
		cout << i << '*' << i << '*' << i << '=' << p << endl;
	}
}
inline int cube(int n) {
	return n * n * n;
}