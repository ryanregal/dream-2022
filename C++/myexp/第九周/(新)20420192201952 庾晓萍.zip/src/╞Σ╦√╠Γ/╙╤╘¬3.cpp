#include <iostream>
class Animal;
void setValue(Animal&, int);
void setValue(Animal&, int, int);

class Animal {
public:
	 friend void SetValue(Animal&, int);
	 //��Ҫ������Ԫ
	 friend void SetValue(Animal & ta, int tw, int tn);
protected:
	  int itsWeight;
	  int itsAge;	
};

void SetValue(Animal& ta, int tw) {
	ta.itsWeight = tw;
}
void SetValue(Animal& ta, int tw, int tn) 
{
	ta.itsWeight = tw;
	ta.itsAge = tn;
}

int main() {
	Animal peppy;
	SetValue(peppy, 5);
	SetValue(peppy, 7,9);
	return 0;
}