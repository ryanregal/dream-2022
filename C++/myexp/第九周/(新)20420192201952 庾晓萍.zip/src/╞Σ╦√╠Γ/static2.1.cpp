#include <iostream>
using namespace std;

class Sample {
private:
	int x;

public:
	static int y;  //���1
	Sample(int a) {
		x = a;
		x++;
		y++;
	}
	void print()
	{
		cout << "x = " << x << ", y =" <<y<< endl;
	}
};

int Sample::y = 10;
void main() {
	Sample s1(20);
	Sample s2(30);
	s1.print(); s2.print();
	cout << Sample::y;
}