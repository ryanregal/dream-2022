#include <iostream>
using namespace std;

class Sample {
	int n;
public:
	Sample(int i) { n = i; };
	void print()const;
	void setValue() { n = 100; }
};

void main() {
	const Sample a(10);
	a.print();
}
void Sample::print()const 
{
	//n = 200;
	//error C2166:l-value specifies const object
	//setValue(); 
	//error C2662:"setValue"cannot convert this pointer
	// from const class Sample to class Sample &
	cout << "2:n=" << n << endl;
}