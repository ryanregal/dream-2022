#include <iostream>
using namespace std;

class Complex
{
private:
	double real;
	double im;
public:
	//���캯��
	Complex(double r, double i) {
		real = r;
		im = i;
	}
	Complex(Complex& t) {
		cout << "���ø��ƹ��캯��" << endl;
		real = t.real;
		im = t.im;
	}
	Complex(){}
	Complex& Add(const Complex& t1)  //Ҫ�����ƴ��룬ʵ�ָ����ļ�
	{
		Complex newnum;
		newnum.real = t1.real + real;
		newnum.im = t1.im + im;
		return newnum;
	}
	friend Complex& Add2(const Complex& t1, const Complex& t2);
	void display() { cout << real << ":" << im << endl; }
};

Complex& Add2(const Complex& t1, const Complex& t2)  //Ҫ�����ƴ��룬ʵ�ָ����ļ�
{
	Complex newnum;
	newnum.real = t1.real + t2.real;
	newnum.im = t1.im + t2.im;
	return newnum;
}
int main() {
	Complex p1(11, 12), p2(13, 14);
	Complex c1, c2;
	c1 = p1.Add(p2);
	c2 = Add2(p1, p2);
	c1.display();
	c2.display();
	return 1;
}