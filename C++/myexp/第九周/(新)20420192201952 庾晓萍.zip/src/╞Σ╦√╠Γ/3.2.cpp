#include <iostream>
using namespace std;
class Sample
{
	int n;
public:
	Sample(int i) { n = i; };
	void print() { cout << "1:n=" << n << endl; }
};

void main() {
	const Sample a(10);
	//a.print();
	//error:print cannot convert this pointer
	//from const class Sample to class Sample
	//conversion losser qualifiers
}